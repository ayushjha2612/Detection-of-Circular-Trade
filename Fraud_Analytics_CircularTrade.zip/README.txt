The document in the file Solution.pdf
The Zip contains the Latex code to generate the same
The folder also contains main.ipynb which has the code to reproduce the results
